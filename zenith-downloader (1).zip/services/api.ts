import { VideoQuality, VideoMetadata, DownloadProgress } from '../types';

const API_BASE = 'http://localhost:5000/api';

interface AnalyzeResponse {
  metadata: VideoMetadata;
  qualities: VideoQuality[];
}

// Simple cache to avoid double fetching since App.tsx calls metadata and qualities in parallel
let analysisCache: { url: string; promise: Promise<AnalyzeResponse> } | null = null;

const getAnalysis = (url: string): Promise<AnalyzeResponse> => {
  if (analysisCache && analysisCache.url === url) {
    return analysisCache.promise;
  }

  const promise = fetch(`${API_BASE}/analyze`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url }),
  })
  .then(async (res) => {
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  })
  .catch(err => {
    // Clear cache on error so user can retry
    analysisCache = null;
    if (err.message && err.message.includes('Failed to fetch')) {
        throw new Error("Backend unavailable. Is the Python server running on port 5000?");
    }
    throw err;
  });

  analysisCache = { url, promise };
  return promise;
};

export const fetchMetadata = async (url: string): Promise<VideoMetadata> => {
  const data = await getAnalysis(url);
  return data.metadata;
};

export const fetchQualities = async (url: string): Promise<VideoQuality[]> => {
  const data = await getAnalysis(url);
  return data.qualities;
};

export async function* downloadVideo(url: string, formatId: string, filename: string) {
  let response;
  try {
    response = await fetch(`${API_BASE}/download`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, format_id: formatId, filename }),
    });
  } catch (err: any) {
    if (err.message && err.message.includes('Failed to fetch')) {
        throw new Error("Backend unavailable. Is the Python server running on port 5000?");
    }
    throw err;
  }

  if (!response.body) throw new Error("No response body");

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  let lastPercentage = 0;
  let lastSpeed = '0 MiB/s';
  let lastEta = '--';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n\n');
    buffer = lines.pop() || ''; // Keep incomplete chunk

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          const data = JSON.parse(line.slice(6));

          if (data.status === 'progress') {
            lastPercentage = data.percentage;
            lastSpeed = data.speed;
            lastEta = data.eta;
            
            yield {
              percentage: lastPercentage,
              speed: lastSpeed,
              eta: lastEta,
              currentTask: 'Downloading video data...'
            };
          } else if (data.status === 'log') {
            yield {
              percentage: lastPercentage,
              speed: lastSpeed,
              eta: lastEta,
              currentTask: data.message
            };
          } else if (data.status === 'complete') {
            return;
          } else if (data.status === 'error') {
            throw new Error(data.message);
          }
        } catch (e) {
          console.error("Parse error", e);
        }
      }
    }
  }
}