import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export const generateSmartFilename = async (originalTitle: string): Promise<string> => {
  if (!ai) {
    console.warn("Gemini API key not found. Returning original title.");
    return originalTitle.replace(/[^a-zA-Z0-9]/g, '_');
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `You are a file naming assistant.
      User Input: "${originalTitle}"
      
      Task: Create a concise, clean, file-system friendly filename (snake_case) for this video.
      - Remove special characters.
      - Keep it under 50 chars.
      - Do not include the file extension.
      - Output ONLY the filename string.
      `,
    });

    const text = response.text;
    return text ? text.trim() : originalTitle;
  } catch (error) {
    console.error("Gemini Error:", error);
    return originalTitle;
  }
};