import { VideoQuality, VideoMetadata } from '../types';

// Simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const mockFetchMetadata = async (url: string): Promise<VideoMetadata> => {
  await delay(1500); // Simulate "yt-dlp -j"
  
  // Return fake metadata based on url for demo purposes
  return {
    title: "Understanding the Universe: A Deep Dive into Physics",
    thumbnail: "https://picsum.photos/800/450", // Placeholder
    duration: "14:20"
  };
};

export const mockFetchQualities = async (url: string): Promise<VideoQuality[]> => {
  await delay(1200); // Simulate "yt-dlp -F"
  
  return [
    { id: '137', resolution: '1920x1080', fps: 60, ext: 'mp4', size: '450MB', note: 'High Bitrate' },
    { id: '136', resolution: '1280x720', fps: 60, ext: 'mp4', size: '220MB' },
    { id: '299', resolution: '1920x1080', fps: 30, ext: 'mp4', size: '380MB' },
    { id: '22', resolution: '1280x720', fps: 30, ext: 'mp4', size: '150MB' },
    { id: '18', resolution: '640x360', fps: 30, ext: 'mp4', size: '85MB' },
  ];
};

// Generator to simulate stream of download progress
export async function* mockDownloadStream() {
  const tasks = [
    "Resolving download URLs...",
    "Connecting to server...",
    "Downloading video stream...",
    "Downloading audio stream...",
    "Merging formats...",
    "Finalizing..."
  ];

  for (let i = 0; i <= 100; i += Math.floor(Math.random() * 5) + 1) {
    const isAudio = i > 40 && i < 70;
    const isMerge = i >= 90;
    
    let task = tasks[2];
    if (i < 5) task = tasks[0];
    else if (i < 10) task = tasks[1];
    else if (isAudio) task = tasks[3];
    else if (isMerge) task = tasks[4];
    
    // Simulate varying speed
    const speed = `${(Math.random() * 5 + 2).toFixed(1)} MiB/s`;
    const eta = `${Math.max(0, 60 - Math.floor(i * 0.6))}s`;

    yield {
      percentage: Math.min(i, 100),
      speed,
      eta,
      currentTask: task
    };

    await delay(Math.random() * 200 + 50); // Random network jitter
  }
}